package dao;

public class ActorDao {

}
